---
name: codex-intercom
description: |
  Coordinate with local Pi or Codex sessions through codex-intercom MCP tools.
  Use for same-machine planner-worker workflows, direct peer questions,
  cross-session context sharing, and checking or replying to pending asks.
---

# Codex Intercom

Use this skill when you need to coordinate with another local coding-agent
session through the `codex-intercom` MCP server (or its configured alias).

Codex cannot currently receive unsolicited MCP messages as a fresh visible turn.
Inbound messages are queued by the MCP server while it is running. Check
`intercom_pending` at natural boundaries, before starting delegated work, and
when you expect a response.

When the user's task depends on delegated results, keep the turn active: do
independent work first, then call `intercom_pending({ mark_read: true, wait_ms:
60000 })`. This waits for ordinary completion messages sent with `intercom_send`.
Process reports as they arrive and repeat the bounded wait while required
results remain outstanding. An empty inbox or timeout does not mean the task
is complete. Use `coi` if messages must wake Codex after its turn has ended.

If the user needs wake-on-message behavior, use or recommend the app-server
bridge daemon. It exposes configured virtual Codex workers as intercom sessions;
messages to those workers create or resume app-server threads and start turns.

## Tools

- `intercom_whoami`: show this session's intercom ID, name, cwd, and model.
- `intercom_team({ team? })`: inspect one task team or list all memberships; falls back to managed-team discovery.
- `intercom_join({ name?, create?, members?, work? })`: list, join, or create an additive task team; the manager adds connected peers in one call.
- `intercom_status`: check connection, active session count, unread messages,
  and unresolved inbound asks.
- `intercom_list`: list connected Pi and Codex sessions.
- `intercom_set_summary`: publish a short discoverable status.
- `intercom_send`: fire-and-forget direct message.
- `intercom_ask`: send a question and wait for the target's reply.
- `intercom_pending`: read queued inbound messages and pending asks; `wait_ms`
  waits up to 60000 ms when the inbox is empty.
- `intercom_reply`: reply to a pending inbound ask.

## Workflow

1. For a known recipient, call `intercom_send` directly. Do not run `intercom_whoami`, `intercom_team`, `intercom_list`, or `intercom_status` as routine preflight checks. If the host requires tool discovery, discover only the selected tool and reuse its definition while it remains in context.
2. Discover peers only when the recipient is unknown, missing, or ambiguous: use `intercom_team` for managed or approved teammates, otherwise `intercom_list`. Check `intercom_status` only for connection errors. Use `intercom_set_summary` only when peers need to discover your role or a meaningful status change.
3. When the user delegates to named peers and this task has no approved team, ask once whether to form a team with you and those peers. Wait for approval. An explicit create/join request is approval; never ask again for an approved task or inbound team message. After approval, discover peers and call `intercom_join({ name: "billing", create: true, members: ["front", "writer"], work: "Current task" })`. Do not ask the user to join each terminal manually. Reuse the approved team for the same task; new tasks may need new teams. Joining preserves all previous memberships and each team's manager/member roles.
4. Use `intercom_send` for non-blocking updates and handoffs. Include `team` for task messages, especially when multiple teams are shared. Without a shared team, omit `team` for initial ungrouped contact; unrelated memberships do not block contact or silently create teams.
5. Use `intercom_ask` only when you need the answer before continuing. Assignments, progress/status checkpoints, notifications, and completion reports use `intercom_send`.
6. Check `intercom_pending` at natural work boundaries when expecting a response or handling inbound messages, then reply with the original selectors and team. A standalone successful send does not require a pending/identity/status check or a resend. Delivery is not task completion; diagnose uncertain delivery before retrying, and never poll in a tight loop.

Delegation requires a reachable return address. Use this persistent MCP runtime or a `coi` session for assignments, questions, and completion reports. Do not work around unavailable tools by creating a random one-shot `IntercomClient`, sending a task, and immediately disconnecting: the recipient's later response will fail with `Session not found`. For a shell-only acknowledgement, the Pi package's `intercom-send --wait-reply 60 <recipient> <message>` keeps its independent sender alive until the first response; ongoing work still needs a persistent session. If a reply fails to an offline sender, check delivery evidence before resending the original task.

## Patterns

Planner delegates without waiting:

```typescript
intercom_send({
  to: "worker",
  message: "Task-3: Add retry logic in src/api/client.ts. Ask if the retry scope is unclear."
})
```

Worker asks and waits:

```typescript
intercom_ask({
  to: "planner",
  message: "Should retry apply only to idempotent endpoints? Proposed: GET/PUT/DELETE, max 3, exponential backoff."
})
```

Reply to an inbound ask:

```typescript
intercom_pending({ mark_read: false })
intercom_reply({ message: "Use GET/PUT/DELETE only, max 3 retries." })
```

Replies inherit the original message's team, never a mutable current team. Prefer `askId` or `contextId` returned by `intercom_pending` (contextId also selects ordinary messages). Mixed-team pending contexts require explicit selection; `team` cannot override the original. Within one task, `to` plus `oldest`/`latest` also selects an ask:

```typescript
intercom_reply({
  to: "planner",
  which: "oldest",
  message: "Proceed, but preserve the public error shape."
})
```

Keep at most one unresolved `intercom_ask` to the same recipient. Use `intercom_send` for non-blocking follow-ups and every progress/status request.

Wake a bridge-managed worker:

```typescript
intercom_ask({
  to: "codex-worker",
  message: "Please inspect the failing test and reply with the most likely cause."
})
```

## Boundaries

- Do not assume push delivery into Codex. Check `intercom_pending`.
- Do not assume a normal MCP session can wake itself from idle. Use the
  app-server bridge for wake-on-message virtual workers.
- Do not use `intercom_ask` for passive polling of files, ports, or process
  completion. Use normal shell checks for those.
- Keep messages concise and include file paths, command output summaries, and
  decision options when useful.
