# Changelog

## 0.16.0 - 2026-10-11

- Add opt-in `cci --tui --channel` wakeups through Claude Code Channels, sharing the existing MCP identity and unread inbox. Messages queued before initialization trigger a notice without a first user prompt.
- Deduplicate unread notices, preserve messages until explicit reads, and use exactly one original context or ask selector for replies. Keep Monitor disabled in channel mode.
- Verify broker delivery, cold-start channel wakeups, and real CPA GPT 6.1 replies. Document setup and current Claude startup warnings.

## 0.15.1 - 2026-10-04

- Add shortest-path MCP instructions and align the Claude skill: send directly to known recipients; discover peers, diagnose connections, publish summaries, and poll inboxes only when needed. Keep team approval, reply threading, and natural-boundary inbound checks unchanged.

## 0.15.0 - 2026-10-02

- Add additive task teams shared with Pi, OpenCode, and Codex: one manager-approved call adds named peers without switching registration scope or losing previous memberships.
- Preserve task teams on sends, asks, native relays, and automatic worker replies; receiver-local ask/context selectors prevent mixed-task replies and support ordinary inbound messages.
- Prompt once for team approval on new delegations. Initial ungrouped contact remains possible across unrelated memberships.

## 0.14.1 - 2026-09-30

- Expose the existing MCP owner's `runtimeReady` promise to companion Grok/AGY launchers so native identity and title updates use `syncSession` without opening a competing broker connection.

## 0.14.0 - 2026-09-30

- Register ordinary MCP launches before the first prompt/tool call; packaged SessionStart/SessionEnd hooks synchronize native conversation identity without creating a competing broker connection.
- Forward `cci --tui --name` to Claude's native title and synchronize `/rename` into broker presence in MCP and verified native modes. Preserve launcher IDs, resume targets, and the existing native compatibility gate.
- Retain messages received during Monitor startup and follow conversation changes after `/clear`.
- Pause automatic reconnect on `SESSION_ID_IN_USE`, expose the conflict in `intercom_status`, and cancel pending reply waiters when a session ends.

## 0.13.1 - 2026-09-06

- Stable release of named teams without tmux. `intercom_join`, `/intercom-create`, and `/intercom-join` work outside TmuxDeck.

## 0.13.0-connect.9 - 2026-09-06

- Add `intercom_join` so Claude sessions can create or join a named team without tmux. `/intercom-create` and `/intercom-join` call the same tool. Named teams share `~/.pi/agent/intercom/named-teams.json` with Pi, Codex, and OpenCode.

## 0.13.0-connect.8 - 2026-08-24

- Document Grok Build and AGY support in detail on the npm package page, including packages, tools, identity, shared scope, Auto-Team participation, and polling-only delivery.
- Add Grok Build and AGY to npm search metadata and clarify that their dedicated launchers load the Claude MCP runtime without a separate `claude-intercom-mcp` installation.

## 0.13.0-connect.7 - 2026-08-24

- Synchronize companion install pins with the hosted-CI-validated Orchestrator release.

## 0.13.0-connect.6 - 2026-08-24

- Synchronize companion install pins with the final systemd-validated Orchestrator release.

## 0.13.0-connect.5 - 2026-08-24

- Synchronize companion Pi and Orchestrator install pins with their final Grok/AGY documentation release.

## 0.13.0-connect.4 - 2026-08-24

- Add the npm-packaged Grok Build and AGY MCP adapters to the synchronized Agent Intercom family documentation.
- Document their polling-only delivery model and shared Claude MCP runtime.

## 0.13.0-connect.3 - 2026-08-23

- Add complete OpenAI MCP annotations for all nine Intercom tools and verify their exact semantics in tests.
- Reference every MCP tool by name so tool coverage is complete.
- Explicitly disable shell execution for production and release-verification child processes.

## 0.13.0-connect.2 - 2026-08-18

- Document standard stdio MCP setup for Grok Build and AGY, including host-neutral identity variables, scope requirements, source-checkout configuration, manual `intercom_pending` polling, and the absence of wake-on-message support.

## 0.12.0-connect.3 - 2026-08-14

- Fix package bundling by adding `monitors/**/*` (`monitors/monitors.json`) to `package.json` `files`, ensuring Claude Code plugin monitor configurations resolve properly at runtime when installed from the packaged npm artifact.
- Add packed runtime verifier and test assertions to validate the complete plugin + MCP + monitors + skills + commands + dist execution chain and path consistency across packed releases.
- Clarify npm registry availability under dist-tag `connect` (`@ctliz/agent-intercom-claude@connect` / `@ctliz/agent-intercom-claude@0.12.0-connect.3`) while preserving exact GitHub tag and remove-before-install instructions.

## 0.12.0-connect.1 - 2026-08-14

- Introduce Intercom protocol v4 candidate with private scoped brokering. `AGENT_INTERCOM_SCOPE_ID` is parsed against `^[A-Za-z0-9_-]{16,128}$` at every `IntercomClient` and captured on register only; list, presence, lifecycle, and name/prefix routing are restricted to the same scope while exact full IDs still cross scopes. Replacement orders the old-scope `session_left` before the new-scope `session_joined` and discards any late frame from the pre-replacement socket. Incompatible brokers fail closed without killing, downgrading, or creating second islands. The `@dataforxyz/agent-intercom-core` dependency is pinned to canonical commit `aad1985e125516b318181560293145bf2507cc6d` (`v0.1.0-connect.1`).
- Add a version-gated native Claude cross-session transport for live `cci --tui` sessions, preserving the MCP/plugin/Monitor transport as an explicit fallback. `auto` enables native only for verified Claude Code 2.1.220–2.1.226, falls back to MCP when native attachment fails, and explicit native selection fails closed.
- Enable Claude's native cross-session feature flag automatically, follow `CLAUDE_CONFIG_DIR` profile registries, and instruct live Claude sessions to relay peer answers with the built-in `SendMessage` tool. A live authenticated Claude Code 2.1.226 socket round trip verified injection and reply delivery.
- Apply the same `auto | native | mcp` selection to headless `cci`/`ccim` and worker JSON configuration; native headless turns keep direct broker wake/reply handling while omitting the packaged Intercom MCP server.
- Credit the MIT-licensed `pi-claude-link` registry/socket protocol implementation adapted by the native bridge.
- Pin Core `aad1985e` and add the dormant Stage-B Boss contract foundation: exact base-v3 capability parsing, optional authoritative bindings, feature-aware run ACLs/discovery, and correlated typed-control validation. The production MCP surface remains unavailable until protected Controller transport and durable dispatch exist.
- Make `cci` and worker launches safe by default, validate Claude permission modes, reject appended permission overrides, and force Adversary/Council workers and their subagents under a read-only `plan` ceiling.
- Reject every appended single-dash option cluster for hardened Claude roles, including Commander forms such as `-pwoutside`, before configuration acceptance or process spawn.
- Keep Core as one required runtime peer by externalizing its root and subpath imports from every bundle, with exact commit/artifact provenance gates for Core `0.1.0`.
- Reject competing live runtimes that claim an active stable session ID while preserving legitimate reconnects and pending deliveries.
- Add ID-free `oldest`/`latest` selection for multiple pending asks from one sender, hide protocol IDs from pending output, and refuse a second unresolved ask to the same recipient.
- Automatically reconnect persistent workers and MCP runtimes with their stable Intercom identity after broker restarts.
- Clarify that assignments and progress/status checkpoints use `intercom_send`, reserving `intercom_ask` for blocking decisions.

## 0.10.0 - 2026-07-16

- Add `intercom_team` so owned Claude coworkers can find their current manager and live siblings without a global peer search.
- Automatically supply the packaged Intercom MCP server to normal headless `cci` workers, including isolated proxy-backed Claude profiles.

## 0.9.3 - 2026-07-15

- Coordinate the Agent Intercom family on the `0.9.3` release line.

## 0.9.2 - 2026-07-14

- Coordinate the Agent Intercom family on the `0.9.2` release line.
- Declare canonical GitHub repository metadata for npm provenance verification.

- Add CI for branches and pull requests.
- Add tag-driven npm trusted publishing with provenance and automatic GitHub Releases.

## 0.9.1 - 2026-07-14

- Publish the package under the public npm scope `@dataforxyz/agent-intercom-claude`.
- Keep the Git repository and executable names unchanged.

## 0.9.0 - 2026-07-14

- Align the Agent Intercom family on one coordinated `0.9.0` release line.
- No behavior change from the immediately preceding AGPL release.

## 0.3.0 - 2026-07-14

- Forward Claude effort selection through `cci` and orchestrator-managed workers.
- Changed the current project license to `AGPL-3.0-or-later`. Previously published MIT versions remain under MIT, and original `pi-intercom` notices are preserved in `THIRD_PARTY_NOTICES.md`.

## 0.2.0

- Upgrade the bundled broker and client to strict intercom protocol v3.
- Add receiver acknowledgements/rejections and broker-confirmed ask defer/cancel controls.
- Add durable sender outboxes with reconnect replay and incompatible-broker replacement.
- Add Alt+I contact copying to interactive `cci` and `ccim` launchers.
