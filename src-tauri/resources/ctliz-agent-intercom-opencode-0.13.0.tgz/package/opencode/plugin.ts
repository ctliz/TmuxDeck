import { appendFileSync } from "fs";
import { resolve } from "node:path";
import { tool, type Plugin } from "@opencode-ai/plugin";
import { intercomScopeIdFromEnv } from "../protocol-v4/contract.ts";
import { OpenCodeIntercomRuntime, formatAttachments, formatSessionDisplay, type PendingInboundMessage } from "./runtime.ts";
import { normalizeOpenCodeSessionStatus, OpenCodePeerHealthReporter } from "./health.ts";
import { invokeAgentFleet, isFleetManagementEnabled } from "./fleet.ts";
import { startOpenCodeControlServer } from "./control.ts";
import { validateAskTimeoutMs } from "../config.ts";
import { contextId, replyHint } from "./reply-context.ts";
import { TASK_TEAM_GUIDANCE } from "./team-guidance.ts";

// Public, bundled contract surface. Production creation intentionally fails
// closed until the protected authority client and typed notice ingress exist.
export {
  createProductionOpenCodeNoticeRecipientIngress,
  DurableOpenCodeNoticeIngressStore,
  getOpenCodeNoticeIngressStatePath,
  OpenCodeNoticeAuthorityUnavailableError,
  OpenCodeNoticeCurrentClaimUnavailableError,
  OpenCodeNoticeRecipientIngress,
  OPENCODE_NOTICE_AUTHORITY_UNAVAILABLE,
  OPENCODE_NOTICE_CURRENT_CLAIM_EVIDENCE_VERSION,
  OPENCODE_NOTICE_CURRENT_CLAIM_UNAVAILABLE,
} from "./notice-ingress.ts";

const INJECT_LOG_PATH = "/tmp/intercom-inject.log";

interface PendingInjectEntry {
  entry: PendingInboundMessage;
}

function resultText(result: { content: Array<{ type: "text"; text: string }>; isError?: boolean }): string {
  const text = result.content.map(part => part.text).join("\n");
  if (result.isError) {
    throw new Error(text);
  }
  return text;
}

function listScope(value: string | undefined): "machine" | "directory" | "repo" {
  if (value === undefined) return "machine";
  if (value === "machine" || value === "directory" || value === "repo") return value;
  throw new Error('scope must be one of "machine", "directory", or "repo"');
}

function isDifferentDirectory(dir1: string, dir2: string): boolean {
  try {
    return resolve(dir1) !== resolve(dir2);
  } catch {
    return false;
  }
}

export interface OpenCodePluginOptions {
  runtime?: OpenCodeIntercomRuntime;
}

export const OpenCodeIntercomPlugin: Plugin = async ({ client, directory, serverUrl }, pluginOptions?: OpenCodePluginOptions) => {
  // Capture scope at entry and fail-closed immediately if invalid
  const capturedScopeId = intercomScopeIdFromEnv(process.env);
  const pinnedSessionID = process.env.OPENCODE_INTERCOM_TARGET_SESSION?.trim() || process.env.OPENCODE_SESSION_ID?.trim() || undefined;
  let activeSessionID = pinnedSessionID;
  const isTargetSessionPinned = Boolean(pinnedSessionID);
  let activeSessionStatus = "idle";
  let sessionEventRevision = 0;
  const knownSessionIDs = new Set<string>();
  const subagentSessionIDs = new Set<string>();
  let flushingInjectQueue = false;
  const pendingInjectQueue: PendingInjectEntry[] = [];
  const deliveredMessageIDs = new Set<string>();
  let runtime: OpenCodeIntercomRuntime;
  let healthReporter: OpenCodePeerHealthReporter;
  const canUseTuiInjection = Boolean(process.stdin.isTTY || process.stdout.isTTY);
  const debugInject = process.env.OPENCODE_INTERCOM_DEBUG === "1";
  const fleetManagementEnabled = isFleetManagementEnabled();
  let fleetHeartbeatRunning = false;
  let fleetHeartbeat: NodeJS.Timeout | undefined;

  function logInject(step: string, details: Record<string, unknown>): void {
    if (!debugInject) {
      return;
    }
    try {
      appendFileSync(INJECT_LOG_PATH, `${JSON.stringify({ time: new Date().toISOString(), step, ...details })}\n`);
    } catch {
      // Ignore logging failures to avoid breaking message delivery.
    }
  }

  function formatError(error: unknown): Record<string, unknown> {
    if (error instanceof Error) {
      return {
        name: error.name,
        message: error.message,
        stack: error.stack,
        cause: error.cause,
      };
    }
    return { value: error };
  }

  async function logResult(step: string, result: {
    data?: unknown;
    error?: unknown;
    response?: Response;
  }, details: Record<string, unknown> = {}): Promise<void> {
    const responseBody = result.response
      ? await result.response.clone().text().catch(() => undefined)
      : undefined;
    logInject(step, {
      ...details,
      ok: result.error === undefined,
      status: result.response?.status,
      data: result.data,
      error: result.error,
      responseBody,
    });
  }

  function rememberBounded(values: Set<string>, value: string, limit = 4096): void {
    values.add(value);
    while (values.size > limit) {
      const oldest = values.values().next().value;
      if (typeof oldest !== "string") break;
      values.delete(oldest);
    }
  }

  function setActiveSession(sessionID: unknown): void {
    if (typeof sessionID === "string" && sessionID.trim()) {
      rememberBounded(knownSessionIDs, sessionID);
      if (isTargetSessionPinned || subagentSessionIDs.has(sessionID)) {
        return;
      }
      activeSessionID = sessionID;
      healthReporter?.update({ openCodeSessionId: sessionID, status: activeSessionStatus });
    }
  }

  function messageMarker(messageID: string): string {
    return `[agent-intercom-message:${messageID}]`;
  }

  function formatInboundPrompt(entry: PendingInboundMessage): string {
    const from = formatSessionDisplay(entry.from);
    const hint = `\n\nReply with intercom_reply({ contextId: "${contextId(entry)}", message: "..." }). The reply inherits this message's team; do not mix other task contexts.`;
    return [
      `Incoming intercom message from ${from}${replyHint(entry)} (${entry.from.model}, ${entry.from.cwd}):`,
      "",
      entry.message.content.text + formatAttachments(entry.message.content.attachments),
      hint,
      messageMarker(entry.message.id),
    ].join("\n");
  }

  async function resolveActiveSessionID(): Promise<string | undefined> {
    const revisionAtStart = sessionEventRevision;
    if (activeSessionID) {
      if (typeof client?.session?.get === "function") {
        const sessionResult = await client.session.get({
          path: { id: activeSessionID },
          query: { directory },
        }).catch((error) => {
          logInject("session.get.error", { activeSessionID, error: formatError(error) });
          return undefined;
        });
        if (sessionEventRevision !== revisionAtStart) {
          return activeSessionID;
        }
        const session = sessionResult?.data;
        if (session && !session.parentID) {
          const sessionDir = session.directory?.trim();
          if (!sessionDir || !directory || !isDifferentDirectory(sessionDir, directory)) {
            if (session.title?.trim()) {
              await runtime.setName(session.title.trim());
            }
          }
        }
      }
      return activeSessionID;
    }

    if (typeof client?.session?.list !== "function") {
      return undefined;
    }

    const sessionList = await client.session.list({ query: { directory } }).catch((error) => {
      logInject("session.list.error", { error: formatError(error) });
      return undefined;
    });
    if (sessionList) {
      await logResult("session.list", sessionList);
    }
    const sessions = sessionList?.data;
    if (!sessions?.length) {
      return undefined;
    }

    for (const session of sessions) {
      if (session.parentID) {
        rememberBounded(subagentSessionIDs, session.id);
      }
    }

    if (sessionEventRevision !== revisionAtStart || activeSessionID !== undefined) {
      return activeSessionID;
    }

    const topLevelSessions = sessions.filter((session) => !session.parentID);
    if (!topLevelSessions.length) {
      return undefined;
    }

    const latestSession = topLevelSessions.reduce((latest, session) => {
      if (session.time.created > latest.time.created) {
        return session;
      }
      if (session.time.created === latest.time.created && session.time.updated > latest.time.updated) {
        return session;
      }
      return latest;
    });
    setActiveSession(latestSession.id);
    logInject("session.resolve", { sessionID: latestSession.id, sessionCount: sessions.length });
    if (!latestSession.parentID && latestSession.title?.trim()) {
      await runtime.setName(latestSession.title.trim());
    }
    return latestSession.id;
  }

  function enqueuePendingInject(entry: PendingInboundMessage, reason: string): void {
    if (deliveredMessageIDs.has(entry.message.id)) {
      logInject("queue.skip_delivered", { reason, messageID: entry.message.id });
      return;
    }
    if (pendingInjectQueue.some((queued) => queued.entry.message.id === entry.message.id)) {
      logInject("queue.skip_duplicate", { reason, messageID: entry.message.id });
      return;
    }
    pendingInjectQueue.push({ entry });
    logInject("queue.enqueue", { reason, messageID: entry.message.id, queueLength: pendingInjectQueue.length });
  }

  function markDelivered(messageID: string, path: string): void {
    rememberBounded(deliveredMessageIDs, messageID);
    runtime.markInboundInjected(messageID);
    const queueIndex = pendingInjectQueue.findIndex((queued) => queued.entry.message.id === messageID);
    if (queueIndex >= 0) {
      pendingInjectQueue.splice(queueIndex, 1);
    }
    logInject("message.delivered", { messageID, path, queueLength: pendingInjectQueue.length });
  }

  async function sessionAlreadyContainsMessage(sessionID: string, messageID: string): Promise<boolean> {
    const marker = messageMarker(messageID);
    const result = await client.session.messages({
      path: { id: sessionID },
      query: { directory, limit: 200 },
    }).catch((error) => {
      logInject("session.messages.error", { sessionID, messageID, error: formatError(error) });
      return undefined;
    });
    const messages = result?.data;
    if (!messages) return false;
    return messages.some((message) => message.parts.some((part) => {
      if (part.type !== "text") return false;
      const metadata = part.metadata as Record<string, unknown> | undefined;
      return metadata?.intercomMessageId === messageID || part.text.includes(marker);
    }));
  }

  async function flushPendingInjectQueue(trigger: string): Promise<void> {
    if (flushingInjectQueue || !pendingInjectQueue.length) {
      return;
    }

    const sessionID = await resolveActiveSessionID();
    if (!sessionID) {
      logInject("queue.flush.skip", { trigger, reason: "no_session_id", queueLength: pendingInjectQueue.length });
      return;
    }

    flushingInjectQueue = true;
    logInject("queue.flush.start", { trigger, sessionID, queueLength: pendingInjectQueue.length });
    try {
      while (pendingInjectQueue.length) {
        const queued = pendingInjectQueue[0];
        const entry = queued.entry;
        if (deliveredMessageIDs.has(entry.message.id)) {
          pendingInjectQueue.shift();
          logInject("queue.flush.skip_delivered", { trigger, messageID: entry.message.id });
          continue;
        }
        const prompt = formatInboundPrompt(entry);
        if (await sessionAlreadyContainsMessage(sessionID, entry.message.id)) {
          markDelivered(entry.message.id, "session.messages.replay_dedupe");
          continue;
        }
        let result;
        try {
          result = await client.session.promptAsync({
            path: { id: sessionID },
            query: { directory },
            body: {
              parts: [{ type: "text", text: prompt, metadata: { intercomMessageId: entry.message.id } }],
            },
          });
        } catch (error) {
          logInject("queue.flush.promptAsync.throw", {
            trigger,
            sessionID,
            messageID: entry.message.id,
            error: formatError(error),
          });
          break;
        }

        await logResult("queue.flush.promptAsync", result, {
          trigger,
          sessionID,
          messageID: entry.message.id,
        });
        if (result.error !== undefined || !result.response?.ok) {
          break;
        }
        markDelivered(entry.message.id, "queue.flush.promptAsync");
      }
    } finally {
      logInject("queue.flush.end", { trigger, remaining: pendingInjectQueue.length });
      flushingInjectQueue = false;
    }
  }

  async function injectInbound(entry: PendingInboundMessage): Promise<void> {
    const from = formatSessionDisplay(entry.from);
    const prompt = formatInboundPrompt(entry);
    if (deliveredMessageIDs.has(entry.message.id)) {
      logInject("inject.skip_delivered", { messageID: entry.message.id });
      return;
    }
    const busy = activeSessionStatus !== "idle";
    logInject("inject.start", {
      messageID: entry.message.id,
      from,
      activeSessionID,
      activeSessionStatus,
    });

    if (busy) {
      // In opencode run, append/submit may report success without creating a
      // durable follow-up turn, so keep an idle-flush fallback queued.
      enqueuePendingInject(entry, "session_busy_pre_tui");
    }

    logInject("inject.mode", {
      messageID: entry.message.id,
      canUseTuiInjection,
      busy,
    });

    try {
      const toastResult = await client.tui.showToast({
        body: {
          title: `Intercom from ${from}`,
          message: entry.message.content.text.slice(0, 240),
          variant: entry.message.expectsReply ? "warning" : "info",
          duration: 8000,
        },
        query: { directory },
      });
      await logResult("inject.toast", toastResult, { messageID: entry.message.id });
    } catch (error) {
      logInject("inject.toast.throw", { messageID: entry.message.id, error: formatError(error) });
    }

    if (canUseTuiInjection) {
      try {
        const appended = await client.tui.appendPrompt({
          body: { text: prompt },
          query: { directory },
        });
        await logResult("inject.append", appended, { messageID: entry.message.id });
        if (appended.data === true) {
          try {
            const submitResult = await client.tui.submitPrompt({ query: { directory } });
            await logResult("inject.submit", submitResult, { messageID: entry.message.id });
            if (!busy) {
              markDelivered(entry.message.id, "tui.submit");
              return;
            }
          } catch (error) {
            logInject("inject.submit.throw", { messageID: entry.message.id, error: formatError(error) });
          }
        }
      } catch (error) {
        logInject("inject.append.throw", { messageID: entry.message.id, error: formatError(error) });
      }
    } else {
      logInject("inject.tui_skipped", { messageID: entry.message.id, reason: "headless" });
    }

    const sessionID = await resolveActiveSessionID();
    if (!sessionID) {
      logInject("inject.no_session", { messageID: entry.message.id });
      return;
    }

    logInject("inject.session_target", {
      messageID: entry.message.id,
      sessionID,
      activeSessionStatus,
      busy,
    });

    try {
      if (await sessionAlreadyContainsMessage(sessionID, entry.message.id)) {
        markDelivered(entry.message.id, "session.messages.inject_dedupe");
        return;
      }
      const asyncResult = await client.session.promptAsync({
        path: { id: sessionID },
        query: { directory },
        body: {
          parts: [{ type: "text", text: prompt, metadata: { intercomMessageId: entry.message.id } }],
        },
      });
      await logResult("inject.promptAsync", asyncResult, { messageID: entry.message.id, sessionID, busy });
      if (asyncResult.error === undefined && asyncResult.response?.ok) {
        markDelivered(entry.message.id, "session.promptAsync");
      } else {
        enqueuePendingInject(entry, "prompt_async_error");
      }
    } catch (error) {
      logInject("inject.promptAsync.throw", {
        messageID: entry.message.id,
        sessionID,
        error: formatError(error),
      });
      enqueuePendingInject(entry, "prompt_async_throw");
    }
  }

  runtime = pluginOptions?.runtime ?? new OpenCodeIntercomRuntime(undefined, directory, injectInbound, undefined, {
    capturedScopeId,
    onInboundActivity(from) {
      if (!fleetManagementEnabled) return;
      void invokeAgentFleet({ action: "renew", id: from.id }, {
        managerSessionId: runtime.getIdentity().sessionId,
        cwd: directory,
      }, { ...process.env, AGENT_INTERCOM_DISABLE_CLEANUP_TIMER: "1" }).catch(() => undefined);
    },
  });
  const runtimeIdentity = runtime.getIdentity();
  healthReporter = new OpenCodePeerHealthReporter({
    path: process.env.AGENT_INTERCOM_OPENCODE_HEALTH_PATH,
    runId: process.env.AGENT_INTERCOM_RUN_ID,
    workerId: process.env.AGENT_INTERCOM_WORKER_ID,
    intercomSessionId: runtimeIdentity.sessionId,
    serverUrl: serverUrl.toString(),
    directory,
  });
  runtime.setConnectionStateHandler((connected, error) => {
    healthReporter.update({
      connected,
      status: connected ? activeSessionStatus : "reconnecting",
      error: error?.message,
    });
  });
  void (async () => {
    try {
      await runtime.connect();
      healthReporter.update({ connected: true, status: activeSessionStatus, error: undefined });
      await resolveActiveSessionID();
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      healthReporter.update({ connected: false, status: "error", error: message });
      console.error("Failed to start OpenCode intercom listener:", error);
    }
  })();
  if (activeSessionID) rememberBounded(knownSessionIDs, activeSessionID);
  if (fleetManagementEnabled) {
    fleetHeartbeat = setInterval(() => {
      if (fleetHeartbeatRunning) return;
      fleetHeartbeatRunning = true;
      void invokeAgentFleet({ action: "_heartbeat" }, {
        managerSessionId: runtimeIdentity.sessionId,
        cwd: directory,
      }).then(async (result) => {
        const requests = Array.isArray(result?.details?.checkpointRequests) ? result.details.checkpointRequests : [];
        for (const request of requests) {
          if (typeof request?.target !== "string" || typeof request?.message !== "string") continue;
          await runtime.send(request.target, request.message);
        }
      }).catch((error) => {
        logInject("fleet.heartbeat.error", { error: formatError(error) });
      }).finally(() => {
        fleetHeartbeatRunning = false;
      });
    }, 60_000);
    fleetHeartbeat.unref?.();
  }
  const stopControlServer = startOpenCodeControlServer({
    acceptsSession: sessionID => knownSessionIDs.has(sessionID),
    async handle(action) {
      if (action.type === "whoami") {
        return runtime.getIdentity();
      }
      if (action.type === "list") {
        return runtime.sessions(false);
      }
      if (action.type === "send") {
        if (typeof action.to !== "string" || typeof action.message !== "string" || !action.message.trim()) {
          throw new Error("Invalid intercom send request.");
        }
        const result = await runtime.send(action.to, action.message);
        if (result.isError) throw new Error(result.content.map(part => part.text).join("\n"));
        return result.structuredContent ?? { ok: true };
      }
      if (action.type === "join") {
        const result = await runtime.join(action.name, action.create === true);
        if (result.isError) throw new Error(result.content.map(part => part.text).join("\n"));
        return { text: result.content.map(part => part.text).join("\n") };
      }
      throw new Error("Unsupported OpenCode intercom action.");
    },
  });

  return {
    dispose: async () => {
      if (fleetHeartbeat) clearInterval(fleetHeartbeat);
      fleetHeartbeat = undefined;
      stopControlServer();
      healthReporter.update({ connected: false, ready: false, status: "stopped" });
      await runtime.disconnect();
    },

    tool: {
      ...(fleetManagementEnabled ? {
        agent_fleet: tool({
          description: "Create, inspect, adopt, stop, and clean up systemd-owned Pi, Codex, Claude, and OpenCode coworkers. Spawn/list results include direct Intercom targets; list/status default to this manager's workers. Enabled only for an explicitly configured primary OpenCode manager.",
          args: {
            action: tool.schema.string().describe("Fleet action: spawn, list, status, stop, cleanup, doctor, versions, update, logs, renew, forget, adopt, capabilities, profiles, models, variants, or config."),
            id: tool.schema.string().optional().describe("Stable worker ID."),
            harness: tool.schema.string().optional().describe("pi, codex, claude, or opencode."),
            role: tool.schema.string().optional().describe("Worker role or configured role preset."),
            task: tool.schema.string().optional().describe("Assignment or standing mandate."),
            cwd: tool.schema.string().optional().describe("Worker working directory."),
            profile: tool.schema.string().optional().describe("Configured launch profile."),
            model: tool.schema.string().optional().describe("Harness model identifier."),
            effort: tool.schema.string().optional().describe("Normalized effort or OpenCode model variant."),
            instructions: tool.schema.string().optional().describe("Additional standing instructions."),
            fresh: tool.schema.boolean().optional().describe("Start a fresh persistent session rather than resume this worker ID."),
            all: tool.schema.boolean().optional().describe("Include workers owned by other manager sessions for list/status diagnostics."),
            execute: tool.schema.boolean().optional().describe("Actually execute cleanup or updates; false previews."),
            acknowledge: tool.schema.boolean().optional().describe("Manager acknowledgment required before deleting a stopped worker record."),
            lines: tool.schema.number().optional().describe("Journal lines for logs."),
          },
          async execute(args, context) {
            setActiveSession(context.sessionID);
            const result = await invokeAgentFleet(args, {
              managerSessionId: runtimeIdentity.sessionId,
              cwd: directory,
            });
            return resultText(result);
          },
        }),
      } : {}),
      intercom_whoami: tool({
        description: "Show this OpenCode session's intercom identity.",
        args: {},
        async execute(_args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.whoami());
        },
      }),

      intercom_team: tool({
        description: "Show all your named task teams, or inspect one by name. Falls back to managed-team discovery.",
        args: { team: tool.schema.string().optional().describe("Task team to inspect.") },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.team(args.team));
        },
      }),

      intercom_join: tool({
        description: "After user approval, create or join a task team. Membership is additive; members lets the manager add connected peers in one call. Omit name to list teams.",
        args: {
          name: tool.schema.string().optional().describe("Team name to join. Omit to list joinable teams."),
          create: tool.schema.boolean().optional().describe("Create this named team and join as manager. Requires name."),
          members: tool.schema.array(tool.schema.string()).optional().describe("Connected session names or IDs to add; manager only."),
          work: tool.schema.string().optional().describe("Task description when creating a team."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.join(args.name, args.create === true, args.members, args.work));
        },
      }),

      intercom_status: tool({
        description: "Show local intercom connection status and pending message counts.",
        args: {},
        async execute(_args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.status());
        },
      }),

      intercom_list: tool({
        description: "List local Pi, Codex, Claude, and OpenCode intercom sessions.",
        args: {
          scope: tool.schema.string().optional().describe('Filter sessions: "machine", "directory", or "repo".'),
          include_self: tool.schema.boolean().optional().describe("Include this OpenCode session in the result."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.list(listScope(args.scope), args.include_self ?? false));
        },
      }),

      intercom_set_summary: tool({
        description: "Publish a short discoverable status for this OpenCode session.",
        args: {
          summary: tool.schema.string().describe("Short status shown to other intercom sessions."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.setSummary(args.summary));
        },
      }),

      intercom_send: tool({
        description: "Send a non-blocking message to another local intercom session.",
        args: {
          to: tool.schema.string().describe("Target session name, id, or unique id prefix."),
          message: tool.schema.string().describe("Message text to send."),
          team: tool.schema.string().optional().describe("Task team; required when multiple teams are shared. Omit for ungrouped contact."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.send(args.to, args.message, undefined, undefined, args.team));
        },
      }),

      intercom_ask: tool({
        description: "Ask another local intercom session a question only when the next step depends on its reply. Use intercom_send for assignments, progress/status checkpoints, and notifications.",
        args: {
          to: tool.schema.string().describe("Target session name, id, or unique id prefix."),
          message: tool.schema.string().describe("Question text to send."),
          team: tool.schema.string().optional().describe("Task team; required when multiple teams are shared."),
          timeout_ms: tool.schema.number().optional().describe("Reply timeout in milliseconds, max 120000."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          const timeoutMs = args.timeout_ms === undefined
            ? undefined
            : validateAskTimeoutMs(args.timeout_ms);
          return resultText(await runtime.ask(args.to, args.message, undefined, timeoutMs, undefined, args.team));
        },
      }),

      intercom_pending: tool({
        description: "Read queued inbound intercom messages and unresolved asks.",
        args: {
          mark_read: tool.schema.boolean().optional().describe("Mark unread messages as read after returning them."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.pending(args.mark_read ?? false));
        },
      }),

      intercom_reply: tool({
        description: "Reply to an inbound ask or ordinary message using askId or contextId. Inherits the original team; team cannot override it.",
        args: {
          message: tool.schema.string().describe("Reply text."),
          to: tool.schema.string().optional().describe("Optional sender name/id; never a message or thread ID."),
          which: tool.schema.enum(["oldest", "latest"]).optional().describe("Select the oldest or latest ask from the chosen sender."),
          askId: tool.schema.string().optional().describe("Stable pending ask selector from intercom_pending."),
          contextId: tool.schema.string().optional().describe("Exact inbound context selector, including ordinary messages."),
          team: tool.schema.string().optional().describe("Must match the original message; omit to inherit."),
        },
        async execute(args, context) {
          setActiveSession(context.sessionID);
          return resultText(await runtime.reply(args.message, args.to, args.which, args.askId, args.contextId, args.team));
        },
      }),
    },

    "experimental.chat.system.transform": async (_input, output) => {
      output.system.push(TASK_TEAM_GUIDANCE);
    },

    event: async ({ event }) => {
      const properties = (event as { properties?: Record<string, unknown> }).properties;
      if (event.type === "session.created" || event.type === "session.updated") {
        const info = properties?.info as {
          id?: unknown;
          parentID?: unknown;
          directory?: unknown;
          title?: unknown;
        } | undefined;
        const id = typeof info?.id === "string" ? info.id.trim() : undefined;
        if (!id) return;

        const parentID = typeof info?.parentID === "string" ? info.parentID.trim() : undefined;
        if (parentID) {
          rememberBounded(subagentSessionIDs, id);
          rememberBounded(knownSessionIDs, id);
          return;
        }

        const infoDir = typeof info?.directory === "string" ? info.directory.trim() : undefined;
        if (infoDir && directory && isDifferentDirectory(infoDir, directory)) {
          return;
        }

        const title = typeof info?.title === "string" ? info.title.trim() : undefined;
        sessionEventRevision += 1;

        if (event.type === "session.created") {
          setActiveSession(id);
          if ((activeSessionID === id || !activeSessionID) && title) {
            await runtime.setName(title);
          }
        } else if (event.type === "session.updated") {
          if (activeSessionID === undefined) {
            setActiveSession(id);
          }
          if (activeSessionID === id && title) {
            await runtime.setName(title);
          }
        }
      } else {
        const sessionID = typeof properties?.sessionID === "string" ? properties.sessionID.trim() : undefined;
        if (sessionID && !subagentSessionIDs.has(sessionID)) {
          if (activeSessionID === undefined) {
            setActiveSession(sessionID);
          }
        }
      }

      if (event.type === "session.idle") {
        const sessionID = typeof properties?.sessionID === "string" ? properties.sessionID.trim() : undefined;
        if (sessionID && sessionID !== activeSessionID) {
          return;
        }
        activeSessionStatus = "idle";
        healthReporter.update({ status: "idle", connected: true, error: undefined });
        await runtime.setSummary("idle");
        await flushPendingInjectQueue("session.idle");
      } else if (event.type === "session.status") {
        const sessionID = typeof properties?.sessionID === "string" ? properties.sessionID.trim() : undefined;
        if (sessionID && sessionID !== activeSessionID) {
          return;
        }
        const status = normalizeOpenCodeSessionStatus(properties?.status);
        activeSessionStatus = status;
        healthReporter.update({ status, connected: true, error: undefined });
        await runtime.setSummary(status);
      }
    },
  };
};

export default OpenCodeIntercomPlugin;
